A clone of the game Snake. Created to show a way of doing a game in C#.
Demonstrates how to keep a score mostly safe in memory, implementing the
drawing of the game, as well as many other things.

Controls: Use AWSD to control the character.
A - Left
S - Down
D - Right
W - Up

Copyright (C) 2013  Gerald McAlister

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.